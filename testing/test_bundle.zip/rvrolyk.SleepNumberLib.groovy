import groovy.transform.Field

library(
   author: 'rvrolyk',
   name: 'SleepNumberLib',
   namespace: 'rvrolyk',
   description: 'library for Sleep Number'
)

@Field static final Boolean IS_BETA = true
@Field static final String appVersion = '3.3.0'  // public version
@Field static final String NAMESPACE = 'rvrolyk'
@Field static final String DRIVER_PREFIX = 'Test driver'
@Field static final String APP_PREFIX = 'Test app'
@Field static final String BETA_SUFFIX = ' Beta'
static String getAPP_NAME() { APP_PREFIX + (IS_BETA ? BETA_SUFFIX : '') }
static String getDRIVER_NAME() { DRIVER_PREFIX + (IS_BETA ? BETA_SUFFIX : '') }

